# 导入数据库模块并初始化
import sqlite3

con = sqlite3.connect("./base/single.db")
cur = con.cursor()

#验证可用性
cur.execute("SELECT C_key FROM sing_dic WHERE B_Key = 'fcu'")
b4 = cur.fetchall()
print("fcu 「全部」的反馈结果是 %s"% b4)
print("fcu 「词条一」的反馈结果是 %s"% b4[0])
print("fcu 「词条二」的反馈结果是 %s"% b4[1])
cur.execute("SELECT D_key FROM sing_dic WHERE B_Key = 'fcu'")
b5 = cur.fetchall()
print("fcu 「词条一拆分」的反馈结果是 %s"% b5[0])
print("fcu 「词条二拆分」的反馈结果是 %s"% b5[1])
for b0 in b5:
    print("拆分结果为：%s"%b0)
cur.execute("SELECT F_key FROM sing_dic WHERE B_Key = 'fcu'")
b6 = cur.fetchall()
print("fcu 「词条一拼音」的反馈结果是 %s"% b6[0])
print("fcu 「词条二拼音」的反馈结果是 %s"% b6[1])

# 关闭 SQLite 接口
cur.close()
con.close()
