# 导入数据库模块并初始化
import sqlite3
con = sqlite3.connect("./base/single.db")
cur = con.cursor()
cur.execute("create table if not exists sing_dic(A_key primary key,B_Key,C_Key,D_key,E_key,F_key)")
cur.execute("delete from sing_dic")
txt_name = "./base/单字表.txt"
def rd_cont(txt_name):
     rd = open(txt_name, "r",encoding='utf-8')
     while True:
         txt_cont = rd.readline().rstrip()
         if txt_cont == "":
             break
         cut_line = txt_cont.split('\t',5)
         if len(cut_line)==5:
              cut_line.append(" ")
              spelling = str(cut_line[3])
              cur.execute("insert into sing_dic values(?,?,?,?,?,?)", (str(cut_line[0]), str(cut_line[1]),str(cut_line[2]),spelling,str(cut_line[4]),str(cut_line[5])))
         else:
              spelling = str(cut_line[3])
              cur.execute("insert into sing_dic values(?,?,?,?,?,?)", (str(cut_line[0]), str(cut_line[1]),str(cut_line[2]),spelling,str(cut_line[4]),str(cut_line[5])))
         con.commit()
     rd.close()
     return
# 执行从 TXT 到 SQLite 的转存
rd_cont(txt_name)
print("做完了")
# 关闭 SQLite 接口
cur.close()
con.close()
