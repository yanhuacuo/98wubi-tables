## 原作地址

https://github.com/thep0y/fcitx5-themes

## 适应98拆分字体

本次的改动，主要在主题的『theme.conf』中，修改字体为『98WB-1』，以方便显示拆分字体。

## 自助安装

终端输入如下命令即可安装

``````
sh skin.sh
``````
## 类TSF嵌入外观

在 Fcitx5 中，这是『预编辑』嵌入，相关参数为

``````
# 在程序中显示预编辑文本
PreeditInApplication=True
``````
