#!/bin/bash

if [ ! -d ~/.local/share/fcitx5/themes ]; then
  mkdir ~/.local/share/fcitx5/themes
fi

cp -rf ./themes/* ~/.local/share/fcitx5/themes

cp -rf ./conf/*.conf ~/.config/fcitx5/conf

echo "重启『Fcitx5』即可使用新主题了, 修改从下面文件 ："

echo "~/.config/fcitx5/conf/classicui.conf"
