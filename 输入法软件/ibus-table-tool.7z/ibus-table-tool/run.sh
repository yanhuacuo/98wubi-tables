#!/bin/bash 

python3 ./reset_dic.py

sudo apt install ibus-table ibus-table-wubi -y

cd ./achieve

ibus-table-createdb -n wb98.db -s wb98.txt

sudo rm -rf /usr/share/ibus-table/tables/*.db

sudo cp -rf ./wb98.db /usr/share/ibus-table/tables

cd ../../

sudo chmod -R 777 ibus-table-tool
sudo chmod -R 755 /usr/share/ibus-table/tables

echo "重启系统后，在 ibus 的面板下添加「五笔98版」。"
 
