# 导入模块
import os
import re


# 获取文件名
file_list = os.listdir(".")
my_path = os.path.abspath('.')
my_list = list(filter(lambda x: re.match('.*txt', x) != None, file_list)) 

# 抛异常
if len(my_list) != 1:
    print("请在『ibus-table-tool』这个文件夹下面\n只放\n一个『单行单义』的码表文件。")
    input()
    exit()

# 文件名赋值
txt_name = my_list[0]

# 先写表头

# 合成『ibus-table』
# 初始化『new_table』为『wb98.txt』
new_table = open('%s/achieve/wb98.txt'%(my_path),"w",encoding='utf-8')
new_table.close()
# 写入表头
new_table = open('%s/achieve/wb98.txt'%(my_path),"a", encoding='utf-8')
rd_conf = open('%s/base/表头.txt'%(my_path),"r",encoding='utf-8')
while True:
  conf_line = rd_conf.readline()
  new_table.write(conf_line)
  if conf_line == "":
    break
rd_conf.close()
new_table.close()
print("表头写入完毕，\n即将写入码表正文，\n这可能会需要一点时间，\n稍安匆躁。")
# 再写正文
# 写正文
new_table = open('%s/achieve/wb98.txt'%(my_path),"a",encoding='utf-8')
rd_dup = open(txt_name,"r", encoding='utf-8')
freq_num = 900000
while True:
  dup_line = rd_dup.readline().rstrip()
  if dup_line == "":
      break
  cut_line = dup_line.split('\t',1)
  dup = cut_line[1] + '\t' + cut_line[0] + '\t' + str(freq_num) + '\n'
  new_table.write(dup)
  freq_num -= 1
rd_dup.close()
new_table.close()
print("正文已经写好了，\n即将写入构词表。")
# 最后构词表
# 写入造词表
new_table = open('%s/achieve/wb98.txt'%(my_path),"a",encoding='utf-8')
rd_gouci = open('%s/base/造词表.txt'%(my_path),"r",encoding='utf-8')
while True:
  gouci_line = rd_gouci.readline()
  new_table.write(gouci_line)
  if gouci_line == "":
      break
rd_gouci.close()
new_table.close()
print("全部写好，转换成功！")
