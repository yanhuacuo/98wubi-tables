1: 运行98五笔方案安置脚本；

$ sudo chmod a+x ./rime.sh
$ sudo ./rime.sh

2: ubuntu软件商店内搜「ibus-font-setting」，安装，并将字体设为「98WB-1 Regular」，大小随意。
