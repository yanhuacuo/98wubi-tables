﻿托盘图标修改（图标放此目录）：
中文-->cn.ico
英文-->en.ico
大写状态-->Capslock.ico
禁用-->lock.ico