import sqlite3
import os
import re
import shutil
con = sqlite3.connect("./base/single.db")
cur = con.cursor()

# 获取文件名
file_list = os.listdir(".")
my_list = list(filter(lambda x: re.match('.*txt', x) != None, file_list)) 

# 文件名赋值
txt_name = my_list[0]

# 初始化『new_table』为『wb98.txt』
new_table = open('./achieve/wb98.txt', "w", encoding='utf-8')
new_table.close()

# 写入正文
new_table = open('./achieve/wb98.txt', "a", encoding='utf-8')
rd = open(txt_name, "r", encoding='utf-8')

while True:
  a = rd.readline().strip()
  if a == "":
    break
  cut_line = a.split('\t',1)
  codes = str(cut_line[1])
  new_table.write('\n' + cut_line[0]+'\t')
  for key in codes:
      cur.execute("SELECT A_key FROM sing_dic WHERE aim_chars = '%s'"% key)
      b = cur.fetchone()
      new_table.write(str(b[0]))
# 关闭 SQLite 接口
print("转换成功，命名为「wb98.txt」，存放在「achieve」文件夹下。")
cur.close()
con.close()
new_table.close()
rd.close()
